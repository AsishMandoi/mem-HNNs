# QOPTLib

QOPTLib is a quantum computing oriented benchmark for combinatorial optimization. QOPTLib is comprised of 40 different instances, equally distributed among for well-known problems: Traveling Salesman Problem, Vehicle Routing Problem, one-dimensional Bin Packing Problem and the Maximum Cut Problem.
